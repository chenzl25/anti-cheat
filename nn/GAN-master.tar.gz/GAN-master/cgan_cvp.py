import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os,sys

sys.path.append('utils')
from nets import *
from datas import *

def sample_z(m, n):
	return np.random.uniform(-1., 1., size=[m, n])

# for test
def sample_y(m, n, ind):
	y = np.zeros([m,n])
	for i in range(m):
		y[i,ind] = 1
	return y

def concat(z,y):
	return tf.concat([z,y],1)

class CGAN():
	def __init__(self, generator, discriminator, data):
		self.generator = generator
		self.discriminator = discriminator
		self.data = data

		# data
		self.z_dim = self.data.z_dim
		self.y_dim = self.data.y_dim # condition
		self.X_dim = self.data.X_dim

		self.X = tf.placeholder(tf.float32, shape=[None, self.X_dim])
		self.z = tf.placeholder(tf.float32, shape=[None, self.z_dim])
		self.y = tf.placeholder(tf.float32, shape=[None, self.y_dim])

		# nets
		self.G_sample = self.generator(concat(self.z, self.y))

		self.D_real, _ = self.discriminator(concat(self.X, self.y))
		self.D_fake, _ = self.discriminator(concat(self.G_sample, self.y), reuse = True)
		
		# loss
		self.D_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=self.D_real, labels=tf.ones_like(self.D_real))) + tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=self.D_fake, labels=tf.zeros_like(self.D_fake)))
		self.G_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=self.D_fake, labels=tf.ones_like(self.D_fake)))

		# solver
		self.D_solver = tf.train.AdamOptimizer().minimize(self.D_loss, var_list=self.discriminator.vars)
		self.G_solver = tf.train.AdamOptimizer().minimize(self.G_loss, var_list=self.generator.vars)
	
		for var in self.discriminator.vars:
			print var.name
			
		self.saver = tf.train.Saver()
		gpu_options = tf.GPUOptions(allow_growth=True)
		self.sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))

	def train(self, sample_dir, ckpt_dir='ckpt', training_epoches = 2000, batch_size = 256):
		# if os.path.exists(ckpt_dir):
		# 	self.saver = tf.train.import_meta_graph(os.path.join(ckpt_dir, "cgan_cvp.ckpt.meta"))
		# 	self.saver.restore(self.sess, os.path.join(ckpt_dir, "cgan_cvp.ckpt"))
			
		fig_count = 0
		self.sess.run(tf.global_variables_initializer())
		
		for epoch in range(training_epoches):
			# update D
			X_b,y_b = self.data(batch_size)
			self.sess.run(
				self.D_solver,
				feed_dict={self.X: X_b, self.y: y_b, self.z: sample_z(batch_size, self.z_dim)}
				)
			# update G
			k = 1
			for _ in range(k):
				self.sess.run(
					self.G_solver,
					feed_dict={self.y:y_b, self.z: sample_z(batch_size, self.z_dim)}
				)
			
			# save img, model. print loss
			if epoch % 100 == 0 or epoch < 100:
				D_loss_curr = self.sess.run(
						self.D_loss,
            			feed_dict={self.X: X_b, self.y: y_b, self.z: sample_z(batch_size, self.z_dim)})
				G_loss_curr = self.sess.run(
						self.G_loss,
						feed_dict={self.y: y_b, self.z: sample_z(batch_size, self.z_dim)})
				print('Iter: {}; D loss: {:.4}; G_loss: {:.4}'.format(epoch, D_loss_curr, G_loss_curr))

				if epoch % 100 == 0:
					y_s = sample_y(100, self.y_dim, 0)
					samples = self.sess.run(self.G_sample, feed_dict={self.y: y_s, self.z: sample_z(100, self.z_dim)})
					file = open('{}/{}-0.txt'.format(sample_dir, str(epoch).zfill(3)), 'w')
					d_0 = 0
					for i in range(len(samples)):
						sample = samples[i]
						# for j in range(len(sample)):
						# 	sample[j] = sample[j] / sample[-1]
						for j in range(len(sample)/2):
							d_0 += abs(sample[j] - sample[j+len(sample)/2])
						sample = map(lambda x: str(x), sample)
						sample.append(str(0))
						file.write(','.join(sample)+'\n')
					file.close()
					print 'd_0 = ',d_0 / 100

					y_s = sample_y(100, self.y_dim, 1)
					samples = self.sess.run(self.G_sample, feed_dict={self.y: y_s, self.z: sample_z(100, self.z_dim)})
					file = open('{}/{}-1.txt'.format(sample_dir, str(epoch).zfill(3)), 'w')
					d_1 = 0
					for i in range(len(samples)):
						sample = samples[i]
						# for j in range(len(sample)):
						# 	sample[j] = sample[j] / sample[-1]
						for j in range(len(sample)/2):
							d_1 += abs(sample[j] - sample[j+len(sample)/2])
						sample = map(lambda x: str(x), sample)
						sample.append(str(1))
						file.write(','.join(sample)+'\n')
					file.close()
					print 'd_1 = ', d_1 / 100 
				# if epoch % 2000 == 0:
				# 	self.saver.save(self.sess, os.path.join(ckpt_dir, "cgan_cvp.ckpt"))


if __name__ == '__main__':

	os.environ['CUDA_VISIBLE_DEVICES'] = '1'

	# save generated images
	sample_dir = 'Samples/cvp_cgan_mlp'
	if not os.path.exists(sample_dir):
		os.makedirs(sample_dir)

	# param
	generator = G_mlp_cvp()
	discriminator = D_mlp_cvp()

	data = cvp('mlp')

	# run
	cgan = CGAN(generator, discriminator, data)
	cgan.train(sample_dir)

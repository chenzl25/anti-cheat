f = open('test.csv', 'w')
vector = []
for i in range(284):
	vector.append('0')
vector.append('0')
for i in range(1000):
	f.write(','.join(vector) + '\n')

vector = []
for i in range(284):
	vector.append('1')
vector.append('1')
for i in range(1000):
	f.write(','.join(vector) + '\n')